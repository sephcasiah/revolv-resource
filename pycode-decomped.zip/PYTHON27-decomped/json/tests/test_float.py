# uncompyle6 version 3.3.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (v2.7.18:8d21aa21f2, Apr 20 2020, 13:25:05) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: d:\BuildAgent\work\f83b6632d72c7b5b\branches\release\EVE-TRANQUILITY\carbon\src\stackless\Lib\json\tests\test_float.py
# Compiled at: 2012-09-22 05:05:09
import math
from unittest import TestCase
import json

class TestFloat(TestCase):

    def test_floats(self):
        for num in [1617161771.765, math.pi, math.pi ** 100,
         math.pi ** (-100), 3.1]:
            self.assertEqual(float(json.dumps(num)), num)
            self.assertEqual(json.loads(json.dumps(num)), num)
            self.assertEqual(json.loads(unicode(json.dumps(num))), num)

    def test_ints(self):
        for num in [1, 1L, 4294967296L, 18446744073709551616L]:
            self.assertEqual(json.dumps(num), str(num))
            self.assertEqual(int(json.dumps(num)), num)
            self.assertEqual(json.loads(json.dumps(num)), num)
            self.assertEqual(json.loads(unicode(json.dumps(num))), num)