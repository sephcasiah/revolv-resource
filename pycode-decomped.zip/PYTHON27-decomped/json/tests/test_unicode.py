# uncompyle6 version 3.3.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (v2.7.18:8d21aa21f2, Apr 20 2020, 13:25:05) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: d:\BuildAgent\work\f83b6632d72c7b5b\branches\release\EVE-TRANQUILITY\carbon\src\stackless\Lib\json\tests\test_unicode.py
# Compiled at: 2012-09-22 05:05:09
from unittest import TestCase
import json
from collections import OrderedDict

class TestUnicode(TestCase):

    def test_encoding1(self):
        encoder = json.JSONEncoder(encoding='utf-8')
        u = u'\u03b1\u03a9'
        s = u.encode('utf-8')
        ju = encoder.encode(u)
        js = encoder.encode(s)
        self.assertEqual(ju, js)

    def test_encoding2(self):
        u = u'\u03b1\u03a9'
        s = u.encode('utf-8')
        ju = json.dumps(u, encoding='utf-8')
        js = json.dumps(s, encoding='utf-8')
        self.assertEqual(ju, js)

    def test_encoding3(self):
        u = u'\u03b1\u03a9'
        j = json.dumps(u)
        self.assertEqual(j, '"\\u03b1\\u03a9"')

    def test_encoding4(self):
        u = u'\u03b1\u03a9'
        j = json.dumps([u])
        self.assertEqual(j, '["\\u03b1\\u03a9"]')

    def test_encoding5(self):
        u = u'\u03b1\u03a9'
        j = json.dumps(u, ensure_ascii=False)
        self.assertEqual(j, (u'"{0}"').format(u))

    def test_encoding6(self):
        u = u'\u03b1\u03a9'
        j = json.dumps([u], ensure_ascii=False)
        self.assertEqual(j, (u'["{0}"]').format(u))

    def test_big_unicode_encode(self):
        u = u'\U0001d120'
        self.assertEqual(json.dumps(u), '"\\ud834\\udd20"')
        self.assertEqual(json.dumps(u, ensure_ascii=False), u'"\U0001d120"')

    def test_big_unicode_decode(self):
        u = u'z\U0001d120x'
        self.assertEqual(json.loads('"' + u + '"'), u)
        self.assertEqual(json.loads('"z\\ud834\\udd20x"'), u)

    def test_unicode_decode(self):
        for i in range(0, 55295):
            u = unichr(i)
            s = ('"\\u{0:04x}"').format(i)
            self.assertEqual(json.loads(s), u)

    def test_object_pairs_hook_with_unicode(self):
        s = u'{"xkd":1, "kcw":2, "art":3, "hxm":4, "qrt":5, "pad":6, "hoy":7}'
        p = [(u'xkd', 1), (u'kcw', 2), (u'art', 3), (u'hxm', 4),
         (u'qrt', 5), (u'pad', 6), (u'hoy', 7)]
        self.assertEqual(json.loads(s), eval(s))
        self.assertEqual(json.loads(s, object_pairs_hook=lambda x: x), p)
        od = json.loads(s, object_pairs_hook=OrderedDict)
        self.assertEqual(od, OrderedDict(p))
        self.assertEqual(type(od), OrderedDict)
        self.assertEqual(json.loads(s, object_pairs_hook=OrderedDict, object_hook=lambda x: None), OrderedDict(p))

    def test_default_encoding(self):
        self.assertEqual(json.loads((u'{"a": "\xe9"}').encode('utf-8')), {'a': u'\xe9'})

    def test_unicode_preservation(self):
        self.assertEqual(type(json.loads(u'""')), unicode)
        self.assertEqual(type(json.loads(u'"a"')), unicode)
        self.assertEqual(type(json.loads(u'["a"]')[0]), unicode)
        self.assertEqual(type(json.loads('"foo"')), unicode)