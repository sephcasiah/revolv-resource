# uncompyle6 version 3.3.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (v2.7.18:8d21aa21f2, Apr 20 2020, 13:25:05) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: d:\BuildAgent\work\f83b6632d72c7b5b\branches\release\EVE-TRANQUILITY\carbon\src\stackless\Lib\json\tests\test_speedups.py
# Compiled at: 2012-09-22 05:05:09
import decimal
from unittest import TestCase
from json import decoder, encoder, scanner

class TestSpeedups(TestCase):

    def test_scanstring(self):
        self.assertEqual(decoder.scanstring.__module__, '_json')
        self.assertTrue(decoder.scanstring is decoder.c_scanstring)

    def test_encode_basestring_ascii(self):
        self.assertEqual(encoder.encode_basestring_ascii.__module__, '_json')
        self.assertTrue(encoder.encode_basestring_ascii is encoder.c_encode_basestring_ascii)


class TestDecode(TestCase):

    def test_make_scanner(self):
        self.assertRaises(AttributeError, scanner.c_make_scanner, 1)

    def test_make_encoder(self):
        self.assertRaises(TypeError, encoder.c_make_encoder, None, "\xcd}=N\x12L\xf9y\xd7R\xba\x82\xf2'J}\xa0\xcau", None)
        return