# uncompyle6 version 3.3.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (v2.7.18:8d21aa21f2, Apr 20 2020, 13:25:05) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: d:\BuildAgent\work\f83b6632d72c7b5b\branches\release\EVE-TRANQUILITY\carbon\src\stackless\Lib\whichdb.py
# Compiled at: 2012-09-22 05:05:20
import os, struct, sys
try:
    import dbm
    _dbmerror = dbm.error
except ImportError:
    dbm = None
    _dbmerror = IOError

def whichdb(filename):
    try:
        f = open(filename + os.extsep + 'pag', 'rb')
        f.close()
        if not (dbm.library == 'GNU gdbm' and sys.platform == 'os2emx'):
            f = open(filename + os.extsep + 'dir', 'rb')
            f.close()
        return 'dbm'
    except IOError:
        try:
            f = open(filename + os.extsep + 'db', 'rb')
            f.close()
            if dbm is not None:
                d = dbm.open(filename)
                d.close()
                return 'dbm'
        except (IOError, _dbmerror):
            pass

    else:
        try:
            os.stat(filename + os.extsep + 'dat')
            size = os.stat(filename + os.extsep + 'dir').st_size
            if size == 0:
                return 'dumbdbm'
            f = open(filename + os.extsep + 'dir', 'rb')
            try:
                if f.read(1) in ("'", '"'):
                    return 'dumbdbm'
            finally:
                f.close()

        except (OSError, IOError):
            pass
        else:
            try:
                f = open(filename, 'rb')
            except IOError:
                return
            else:
                s16 = f.read(16)
                f.close()
                s = s16[0:4]
                if len(s) != 4:
                    return ''
                try:
                    magic, = struct.unpack('=l', s)
                except struct.error:
                    return ''
                else:
                    if magic == 324508366:
                        return 'gdbm'

                if magic in (398689, 1628767744):
                    return 'bsddb185'

            try:
                magic, = struct.unpack('=l', s16[-4:])
            except struct.error:
                return ''

        if magic in (398689, 1628767744):
            return 'dbhash'

    return ''


if __name__ == '__main__':
    for filename in sys.argv[1:]:
        print whichdb(filename) or 'UNKNOWN', filename