# uncompyle6 version 3.3.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (v2.7.18:8d21aa21f2, Apr 20 2020, 13:25:05) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: d:\BuildAgent\work\f83b6632d72c7b5b\branches\release\EVE-TRANQUILITY\carbon\src\stackless\Lib\stacklesslib\replacements\select.py
# Compiled at: 2012-09-22 05:05:13
from __future__ import absolute_import
import stackless, stacklesslib.util, select as real_select
error = real_select.error
__doc__ = real_select.__doc__
_main_thread_id = stackless.main.thread_id

def select(*args, **kwargs):
    if stackless.current.thread_id == _main_thread_id:
        if len(args) == 3 or len(args) == 4 and (args[3] is None or args[3] > 0.05) or 'timeout' in kwargs and (kwargs['timeout'] is None or kwargs['timeout'] > 0.05):
            return stacklesslib.util.call_on_thread(real_select.select, args, kwargs)
    return real_select.select(*args)


select.__doc__ = real_select.select.__doc__