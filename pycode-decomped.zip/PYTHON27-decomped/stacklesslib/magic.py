# uncompyle6 version 3.3.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (v2.7.18:8d21aa21f2, Apr 20 2020, 13:25:05) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: d:\BuildAgent\work\f83b6632d72c7b5b\branches\release\EVE-TRANQUILITY\carbon\src\stackless\Lib\stacklesslib\magic.py
# Compiled at: 2012-09-22 05:05:13
import runpy, os, sys
from .monkeypatch import patch_all
import stackless
from . import main

def run():
    try:
        if len(sys.argv) > 1:
            target = sys.argv.pop(1)
            if target == '-m' and len(sys.argv) > 1:
                target = sys.argv.pop(1)
                runpy.run_module(target, run_name='__main__', alter_sys=True)
            else:
                runpy.run_path(target, run_name='__main__')
    except Exception:
        main.mainloop.exception = sys.exc_info()
        raise
    finally:
        main.mainloop.running = False


if __name__ == '__main__':
    patch_all()
    main.set_scheduling_mode(main.SCHEDULING_ROUNDROBIN)
    stackless.tasklet(run)()
    main.mainloop.run()