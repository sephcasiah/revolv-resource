# uncompyle6 version 3.3.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (v2.7.18:8d21aa21f2, Apr 20 2020, 13:25:05) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: d:\BuildAgent\work\f83b6632d72c7b5b\branches\release\EVE-TRANQUILITY\carbon\src\stackless\Lib\types.py
# Compiled at: 2012-09-22 05:05:20
import sys
NoneType = type(None)
TypeType = type
ObjectType = object
IntType = int
LongType = long
FloatType = float
BooleanType = bool
try:
    ComplexType = complex
except NameError:
    pass
else:
    StringType = str
    try:
        UnicodeType = unicode
        StringTypes = (StringType, UnicodeType)
    except NameError:
        StringTypes = (
         StringType,)

    BufferType = buffer
    TupleType = tuple
    ListType = list
    DictType = DictionaryType = dict

    def _f():
        pass


    FunctionType = type(_f)
    LambdaType = type(lambda : None)
    CodeType = type(_f.func_code)

    def _g():
        yield 1


    GeneratorType = type(_g())

    class _C:

        def _m(self):
            pass


    ClassType = type(_C)
    UnboundMethodType = type(_C._m)
    _x = _C()
    InstanceType = type(_x)
    MethodType = type(_x._m)
    BuiltinFunctionType = type(len)
    BuiltinMethodType = type([].append)
    ModuleType = type(sys)
    FileType = file
    XRangeType = xrange
    try:
        raise TypeError
    except TypeError:
        tb = sys.exc_info()[2]
        TracebackType = type(tb)
        FrameType = type(tb.tb_frame)
        del tb

SliceType = slice
EllipsisType = type(Ellipsis)
DictProxyType = type(TypeType.__dict__)
NotImplementedType = type(NotImplemented)
GetSetDescriptorType = type(FunctionType.func_code)
MemberDescriptorType = type(FunctionType.func_globals)
del sys
del _f
del _g
del _C
del _x