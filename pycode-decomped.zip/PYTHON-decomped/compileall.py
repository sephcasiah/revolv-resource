# uncompyle6 version 3.3.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (v2.7.18:8d21aa21f2, Apr 20 2020, 13:25:05) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: d:\BuildAgent\work\f83b6632d72c7b5b\branches\release\EVE-TRANQUILITY\carbon\src\stackless\Lib\compileall.py
# Compiled at: 2012-09-22 05:05:03
import os, sys, py_compile, struct, imp
__all__ = [
 'compile_dir', 'compile_file', 'compile_path']

def compile_dir(dir, maxlevels=10, ddir=None, force=0, rx=None, quiet=0):
    if not quiet:
        print 'Listing', dir, '...'
    try:
        names = os.listdir(dir)
    except os.error:
        print "Can't list", dir
        names = []

    names.sort()
    success = 1
    for name in names:
        fullname = os.path.join(dir, name)
        if ddir is not None:
            dfile = os.path.join(ddir, name)
        else:
            dfile = None
        if not os.path.isdir(fullname):
            if not compile_file(fullname, ddir, force, rx, quiet):
                success = 0
        elif maxlevels > 0 and name != os.curdir and name != os.pardir and os.path.isdir(fullname) and not os.path.islink(fullname):
            if not compile_dir(fullname, maxlevels - 1, dfile, force, rx, quiet):
                success = 0

    return success


def compile_file(fullname, ddir=None, force=0, rx=None, quiet=0):
    success = 1
    name = os.path.basename(fullname)
    if ddir is not None:
        dfile = os.path.join(ddir, name)
    else:
        dfile = None
    if rx is not None:
        mo = rx.search(fullname)
        if mo:
            return success
    if os.path.isfile(fullname):
        head, tail = name[:-3], name[-3:]
        if tail == '.py':
            if not force:
                try:
                    mtime = int(os.stat(fullname).st_mtime)
                    expect = struct.pack('<4sl', imp.get_magic(), mtime)
                    cfile = fullname + (__debug__ and 'c' or 'o')
                    with open(cfile, 'rb') as (chandle):
                        actual = chandle.read(8)
                    if expect == actual:
                        return success
                except IOError:
                    pass

            if not quiet:
                print 'Compiling', fullname, '...'
            try:
                ok = py_compile.compile(fullname, None, dfile, True)
            except py_compile.PyCompileError as err:
                if quiet:
                    print 'Compiling', fullname, '...'
                print err.msg
                success = 0
            except IOError as e:
                print 'Sorry', e
                success = 0
            else:
                if ok == 0:
                    success = 0
    return success


def compile_path(skip_curdir=1, maxlevels=0, force=0, quiet=0):
    success = 1
    for dir in sys.path:
        if (not dir or dir == os.curdir) and skip_curdir:
            print 'Skipping current directory'
        else:
            success = success and compile_dir(dir, maxlevels, None, force, quiet=quiet)

    return success


def expand_args(args, flist):
    expanded = args[:]
    if flist:
        try:
            if flist == '-':
                fd = sys.stdin
            else:
                fd = open(flist)
            while 1:
                line = fd.readline()
                if not line:
                    break
                expanded.append(line[:-1])

        except IOError:
            print 'Error reading file list %s' % flist
            raise

    return expanded


def main():
    import getopt
    try:
        opts, args = getopt.getopt(sys.argv[1:], 'lfqd:x:i:')
    except getopt.error as msg:
        print msg
        print 'usage: python compileall.py [-l] [-f] [-q] [-d destdir] [-x regexp] [-i list] [directory|file ...]'
        print "-l: don't recurse down"
        print '-f: force rebuild even if timestamps are up-to-date'
        print '-q: quiet operation'
        print '-d destdir: purported directory name for error messages'
        print '   if no directory arguments, -l sys.path is assumed'
        print '-x regexp: skip files matching the regular expression regexp'
        print '   the regexp is searched for in the full path of the file'
        print '-i list: expand list with its content (file and directory names)'
        sys.exit(2)
    else:
        maxlevels = 10
        ddir = None
        force = 0
        quiet = 0
        rx = None
        flist = None
        for o, a in opts:
            if o == '-l':
                maxlevels = 0
            if o == '-d':
                ddir = a
            if o == '-f':
                force = 1
            if o == '-q':
                quiet = 1
            if o == '-x':
                import re
                rx = re.compile(a)
            if o == '-i':
                flist = a

        if ddir:
            if len(args) != 1 and not os.path.isdir(args[0]):
                print '-d destdir require exactly one directory argument'
                sys.exit(2)
        success = 1
        try:
            if args or flist:
                try:
                    if flist:
                        args = expand_args(args, flist)
                except IOError:
                    success = 0

                if success:
                    for arg in args:
                        if os.path.isdir(arg):
                            if not compile_dir(arg, maxlevels, ddir, force, rx, quiet):
                                success = 0
                        elif not compile_file(arg, ddir, force, rx, quiet):
                            success = 0

            else:
                success = compile_path()
        except KeyboardInterrupt:
            print '\n[interrupt]'
            success = 0

    return success


if __name__ == '__main__':
    exit_status = int(not main())
    sys.exit(exit_status)