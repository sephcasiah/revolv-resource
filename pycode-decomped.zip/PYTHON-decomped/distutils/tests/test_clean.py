# uncompyle6 version 3.3.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (v2.7.18:8d21aa21f2, Apr 20 2020, 13:25:05) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: d:\BuildAgent\work\f83b6632d72c7b5b\branches\release\EVE-TRANQUILITY\carbon\src\stackless\Lib\distutils\tests\test_clean.py
# Compiled at: 2012-09-22 05:05:05
import sys, os, unittest, getpass
from distutils.command.clean import clean
from distutils.tests import support

class cleanTestCase(support.TempdirManager, support.LoggingSilencer, unittest.TestCase):

    def test_simple_run(self):
        pkg_dir, dist = self.create_dist()
        cmd = clean(dist)
        dirs = [ (d, os.path.join(pkg_dir, d)) for d in ('build_temp', 'build_lib',
                                                         'bdist_base', 'build_scripts',
                                                         'build_base')
               ]
        for name, path in dirs:
            os.mkdir(path)
            setattr(cmd, name, path)
            if name == 'build_base':
                continue
            for f in ('one', 'two', 'three'):
                self.write_file(os.path.join(path, f))

        cmd.all = 1
        cmd.ensure_finalized()
        cmd.run()
        for name, path in dirs:
            self.assertTrue(not os.path.exists(path), '%s was not removed' % path)

        cmd.all = 1
        cmd.ensure_finalized()
        cmd.run()


def test_suite():
    return unittest.makeSuite(cleanTestCase)


if __name__ == '__main__':
    unittest.main(defaultTest='test_suite')