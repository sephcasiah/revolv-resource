# uncompyle6 version 3.3.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (v2.7.18:8d21aa21f2, Apr 20 2020, 13:25:05) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: d:\BuildAgent\work\f83b6632d72c7b5b\branches\release\EVE-TRANQUILITY\carbon\src\stackless\Lib\distutils\command\__init__.py
# Compiled at: 2012-09-22 05:05:04
__revision__ = '$Id: __init__.py 82110 2010-06-20 13:38:51Z kristjan.jonsson $'
__all__ = [
 'build',
 'build_py',
 'build_ext',
 'build_clib',
 'build_scripts',
 'clean',
 'install',
 'install_lib',
 'install_headers',
 'install_scripts',
 'install_data',
 'sdist',
 'register',
 'bdist',
 'bdist_dumb',
 'bdist_rpm',
 'bdist_wininst',
 'upload',
 'check']