# uncompyle6 version 3.3.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (v2.7.18:8d21aa21f2, Apr 20 2020, 13:25:05) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: d:\BuildAgent\work\f83b6632d72c7b5b\branches\release\EVE-TRANQUILITY\carbon\src\stackless\Lib\distutils\command\install_scripts.py
# Compiled at: 2012-09-22 05:05:04
__revision__ = '$Id: install_scripts.py 82110 2010-06-20 13:38:51Z kristjan.jonsson $'
import os
from distutils.core import Command
from distutils import log
from stat import ST_MODE

class install_scripts(Command):
    description = 'install scripts (Python or otherwise)'
    user_options = [
     ('install-dir=', 'd', 'directory to install scripts to'),
     ('build-dir=', 'b', 'build directory (where to install from)'),
     ('force', 'f', 'force installation (overwrite existing files)'),
     ('skip-build', None, 'skip the build steps')]
    boolean_options = [
     'force', 'skip-build']

    def initialize_options(self):
        self.install_dir = None
        self.force = 0
        self.build_dir = None
        self.skip_build = None
        return

    def finalize_options(self):
        self.set_undefined_options('build', ('build_scripts', 'build_dir'))
        self.set_undefined_options('install', ('install_scripts', 'install_dir'), ('force',
                                                                                   'force'), ('skip_build',
                                                                                              'skip_build'))

    def run(self):
        if not self.skip_build:
            self.run_command('build_scripts')
        self.outfiles = self.copy_tree(self.build_dir, self.install_dir)
        if os.name == 'posix':
            for file in self.get_outputs():
                if self.dry_run:
                    log.info('changing mode of %s', file)
                else:
                    mode = (os.stat(file)[ST_MODE] | 365) & 4095
                    log.info('changing mode of %s to %o', file, mode)
                    os.chmod(file, mode)

    def get_inputs(self):
        return self.distribution.scripts or []

    def get_outputs(self):
        return self.outfiles or []