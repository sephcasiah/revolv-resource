# uncompyle6 version 3.3.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (v2.7.18:8d21aa21f2, Apr 20 2020, 13:25:05) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: d:\BuildAgent\work\f83b6632d72c7b5b\branches\release\EVE-TRANQUILITY\carbon\src\stackless\Lib\bsddb\db.py
# Compiled at: 2012-09-22 05:05:03
import sys
absolute_import = sys.version_info[0] >= 3
if not absolute_import:
    if __name__.startswith('bsddb3.'):
        from _pybsddb import *
        from _pybsddb import __version__
    else:
        from _bsddb import *
        from _bsddb import __version__
else:
    if __name__.startswith('bsddb3.'):
        exec 'from ._pybsddb import *'
        exec 'from ._pybsddb import __version__'
    else:
        exec 'from ._bsddb import *'
        exec 'from ._bsddb import __version__'