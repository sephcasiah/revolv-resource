# uncompyle6 version 3.3.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (v2.7.18:8d21aa21f2, Apr 20 2020, 13:25:05) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: d:\BuildAgent\work\f83b6632d72c7b5b\branches\release\EVE-TRANQUILITY\carbon\src\stackless\Lib\curses\panel.py
# Compiled at: 2012-09-22 05:05:04
__revision__ = '$Id: panel.py 36560 2004-07-18 06:16:08Z tim_one $'
from _curses_panel import *